N=2000;
T=300;k=1.38*10^(-23);
Pf=6.471143*10^(-30);E1=1*10^1;E2=1*10^8;E3=1*10^9;E4=1*10^10;
p1=exp(-Pf*E1*0.1/(k*T));p2=exp(-Pf*E2*0.1/(k*T));p3=exp(-Pf*E3*0.1/(k*T));
p4=exp(-Pf*E4*0.1/(k*T));
a=-1:0.1:1;
date1=fix(21*rand(1,N))/10-1;
date2=fix(21*rand(1,N))/10-1;
date3=fix(21*rand(1,N))/10-1;
date4=fix(21*rand(1,N))/10-1;
ste=1000;
y1=zeros(1,ste);y2=zeros(1,ste);y3=zeros(1,ste);y4=zeros(1,ste);
x=1:1:ste;
for i1= 1:1:ste
   for j1=1:1:N 
   r=rand(1,N);R=rand(1,N);
   if (r(1,j1)<=0.5 && date1(1,j1)<0.98)
       date1(1,j1)=date1(1,j1)+0.1;
   end
   if(r(1,j1)<=0.5 && date1(1,j1)>0.98)
       date1(1,j1)=date1(1,j1);
   end
    if (r(1,j1)>0.5 && R(1,j1)<p1 && date1(1,j1)>-0.98 )
           date1(1,j1)=date1(1,j1)-0.1;
    end
    if(r(1,j1)>0.5 && date1(1,j1)<-0.98)
        date1(1,j1)=date1(1,j1);
    end 
   y1(1,i1)=length(find(date1<1.05&date1>0.95)); 
   end
end
   plot(x,y1,'-.') ;
   hold on
for i2= 1:1:ste
   for j2=1:1:N 
    r=rand(1,N);R=rand(1,N);
   if (r(1,j2)<=0.5 && date2(1,j2)<0.98)
       date2(1,j2)=date2(1,j2)+0.1;
   end
   if(r(1,j2)<=0.5 && date2(1,j2)>0.98)
       date2(1,j2)=date2(1,j2);
   end
    if (r(1,j2)>0.5 && R(1,j2)<p2 && date2(1,j2)>-0.98 )
           date2(1,j2)=date2(1,j2)-0.1;
    end
    if(r(1,j2)>0.5 && date2(1,j2)<-0.98)
        date2(1,j2)=date2(1,j2);
    end 
   y2(1,i2)=length(find(date2<1.05&date2>0.95)); 
   end
end
   plot(x,y2,'-') ;
   hold on
for i3= 1:1:ste
   for j3=1:1:N 
   r=rand(1,N);R=rand(1,N);
   if (r(1,j3)<=0.5 && date3(1,j3)<0.98)
       date3(1,j3)=date3(1,j3)+0.1;
   end
   if(r(1,j3)<=0.5 && date3(1,j3)>0.98)
       date3(1,j3)=date3(1,j3);
   end
    if (r(1,j3)>0.5 && R(1,j3)<p3 && date3(1,j3)>-0.98 )
           date3(1,j3)=date3(1,j3)-0.1;
    end
    if(r(1,j3)>0.5 && date3(1,j3)<-0.98)
        date3(1,j3)=date3(1,j3);
    end 
   y3(1,i3)=length(find(date3<1.05&date3>0.95)); 
   end
end
   plot(x,y3,'--') ;
   hold on
 for i4= 1:1:ste
   for j4=1:1:N 
   r=rand(1,N);R=rand(1,N);
   if (r(1,j4)<=0.5 && date4(1,j4)<0.98)
       date4(1,j4)=date4(1,j4)+0.1;
   end
   if(r(1,j4)<=0.5 && date4(1,j4)>0.98)
       date4(1,j4)=date4(1,j4);
   end
    if (r(1,j4)>0.5 && R(1,j4)<p4 && date4(1,j4)>-0.98 )
           date4(1,j4)=date4(1,j4)-0.1;
    end
    if(r(1,j4)>0.5 && date4(1,j4)<-0.98)
        date4(1,j4)=date4(1,j4);
    end 
   y4(1,i4)=length(find(date4<1.05&date4>0.95)); 
   end
end
   plot(x,y4,'*') ;
  
 