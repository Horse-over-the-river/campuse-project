N=2000;
T=300;k=1.38*10^(-23);
Pf=6.471143*10^(-30);E=2*10^10;
p=exp(-Pf*E*0.1/(k*T));
a=-1:0.1:1;
date=fix(21*rand(1,N))/10-1;
ste=800;
y1=zeros(1,ste);y2=zeros(1,ste);y3=zeros(1,ste);y4=zeros(1,ste);
x=1:1:ste;
for i= 1:1:ste
   for j=1:1:N 
   r=rand(1,N);R=rand(1,N);
   if (r(1,j)<=0.5 && date(1,j)<0.98)
       date(1,j)=date(1,j)+0.1;
   end
   if(r(1,j)<=0.5 && date(1,j)>0.98)
       date(1,j)=date(1,j);
   end
    if (r(1,j)>0.5 && R(1,j)<p && date(1,j)>-0.98 )
           date(1,j)=date(1,j)-0.1;
    end
    if(r(1,j)>0.5 && date(1,j)<-0.98)
        date(1,j)=date(1,j);
    end 
   y1(1,i)=length(find(date<1.05&date>0.95)); y2(1,i)=length(find(date<0.55&date>0.45));
    y3(1,i)=length(find(date<-0.45&date>-0.55)); y4(1,i)=length(find(date<-0.95&date>-1.05));
   end
end
   plot(x,y1,'-.') ;
   hold on
   plot(x,y2,'-');
   hold on
   plot(x,y3,'--')
   hold on
   plot(x,y4,'*')  